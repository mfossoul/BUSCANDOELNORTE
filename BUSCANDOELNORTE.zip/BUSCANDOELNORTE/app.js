// Importar dependencias
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const path = require('path');
const jwt = require('jsonwebtoken');
const { body, validationResult } = require('express-validator');
const cookieParser = require('cookie-parser');
const bcrypt = require('bcryptjs');
const { Client } = require('pg');
const fs = require('fs');


// Configuración de Express
const app = express();
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')))
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(bodyParser.json()); // Middleware para parsear JSON


///////////////////////////////////////////////////////////////////// Conexión a las bases de datos 

///////////////////////////////// MongoDB
//mongoose.connect('mongodb://localhost/BUSCANDOELNORTE')
mongoose.connect('mongodb://localhost/BUSCANDOELNORTE')
  .then(() => console.log('Conexión a MongoDB establecida'))
  .catch(err => console.error('Error al conectar a MongoDB:', err));

//////////////////////////////// Configuración de la conexión a PostgreSQL
const pgClient = new Client({
  user: 'usuariobde',
  host: '172.20.10.2',                         //aqui pones la IP
  database: 'BUSCANDOELNORTE',
  password: 'postgres',
  port: 5432
});
pgClient.connect()
  .then(() => console.log('Conexión a PostgreSQL establecida'))
  .catch(err => console.error('Error al conectar a PostgreSQL:', err));


// Definir esquema de usuario
const usuarioSchema = new mongoose.Schema({
  username: String,
  correo: String,
  passwordHash: String,
  favoritos: [{
    nombre: String,
    fechaAñadido: { type: Date, default: Date.now }
  }]
});
const Usuario = mongoose.model('Usuario', usuarioSchema);


/////////////////////////////////////////////////////////////////////////////////////// Rutas
app.get('/', (req, res) => {
  if (req.cookies.token) {
    try {
      const decoded = jwt.verify(req.cookies.token, process.env.JWT_SECRET);
      req.usuario = decoded;
      return res.redirect('/index2');
    } catch (error) {
      console.error('Error al verificar token:', error);
    }
  }else{
  res.render('index');
  }
});

//////////////////////////////////////////////////////// Rutas para Santiago
{
app.get('/Camino_Santiago/Nombres', async (req, res) => {
  try {
    
    const query = `
      SELECT
        ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, etapa
		
      FROM "Santiago";
    `;
    const result = await pgClient.query(query);
    const geojsonFeatures = result.rows.map(row => ({
      type: "Feature",
      geometry: JSON.parse(row.geometry),
      properties: {
        etapas: row.etapa  
      }
    }));
    const pageTitle = "Buscando el norte";
    const pageSubtitle = "Andando se hace el camino";
    const searchString = ""; 
    const button1 = {
      title: "Area de busqueda",
      description: "Se hara una busqueda en el area visualizada en el mapa",
      link: "/Camino_Santiago/Area"
    };
    const button2 = {
      title: "Busqueda por dificultad",
      description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
      link: "/Camino_Santiago/Dificultad"
    };
    const button3 = {
      title: "Personalizado",
      description: "Se puede hacer una busqueda más concreta",
      link: "/Camino_Santiago/Personalizado"
    };

    // Renderizar la vista web1.ejs con los datos necesarios
    res.render('web1', { pageTitle, pageSubtitle, searchString, button1, button2, button3, routes: geojsonFeatures });
  } catch (err) {
    console.error('Error al obtener datos de PostgreSQL:', err);
    res.status(500).send('Error al obtener datos de PostgreSQL');
  }
});


app.get('/Camino_Santiago/Area', (req, res) => {
    const pageTitle = "Buscando el norte";
    const pageSubtitle = "Andando se hace el camino";
    const searchString = ""; 
    const button1 = {
      title: "Busqueda por nombre",
      description: "Se hara una busqueda por nombre",
      link: "/Camino_Santiago/Nombres"
    };
    const button2 = {
      title: "Busqueda por dificultad",
      description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
      link: "/Camino_Santiago/Dificultad"
    };
    const button3 = {
      title: "Personalizado",
      description: "Se puede hacer una busqueda más concreta",
      link: "/Camino_Santiago/Personalizado"
    };
    res.render('web2', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
});

app.get('/Camino_Santiago/Dificultad', (req, res) => {
    const pageTitle = "Buscando el norte";
    const pageSubtitle = "Andando se hace el camino";
    const searchString = ""; 
    const button1 = {
      title: "Busqueda por nombre",
      description: "Se hara una busqueda por nombre",
      link: "/Camino_Santiago/Nombres"
    };
    const button2 = {
      title: "Area de busqueda",
      description: "Se hara una busqueda en el area visualizada en el mapa",
      link: "/Camino_Santiago/Area"
    };
    const button3 = {
      title: "Personalizado",
      description: "Se puede hacer una busqueda más concreta",
      link: "/Camino_Santiago/Personalizado"
    };
    res.render('web3', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
});

app.get('/Camino_Santiago/Personalizado', (req, res) => {
  const pageTitle = "Buscando el norte";
  const pageSubtitle = "Andando se hace el camino";
  const searchString = ""; 
  const button1 = {
    title: "Busqueda por nombre",
    description: "Se hara una busqueda por nombre",
    link: "/Camino_Santiago/Nombres"
  };
  const button2 = {
    title: "Area de busqueda",
    description: "Se hara una busqueda en el area visualizada en el mapa",
    link: "/Camino_Santiago/Area"
  };
  const button3 = {
    title: "Busqueda por dificultad",
    description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
    link: "/Camino_Santiago/Dificultad"
  };
  res.render('web4', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
});
}

//////////////////////////////////////////////////////// Rutas para FEDME
{
  app.get('/FEDME/Nombres', async (req, res) => {
    try {
      
      const query = `
        SELECT
          ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, nombre
      
        FROM "FEDME";
      `;
      const result = await pgClient.query(query);
      const geojsonFeatures = result.rows.map(row => ({
        type: "Feature",
        geometry: JSON.parse(row.geometry),
        properties: {
          etapas: row.nombre  
        }
      }));
      const pageTitle = "Buscando el norte";
      const pageSubtitle = "Andando se hace el camino";
      const searchString = ""; 
      const button1 = {
        title: "Area de busqueda",
        description: "Se hara una busqueda en el area visualizada en el mapa",
        link: "/FEDME/Area"
      };
      const button2 = {
        title: "Busqueda por dificultad",
        description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
        link: "/FEDME/Dificultad"
      };
      const button3 = {
        title: "Personalizado",
        description: "Se puede hacer una busqueda más concreta",
        link: "/FEDME/Personalizado"
      };
  
      res.render('web1-1', { pageTitle, pageSubtitle, searchString, button1, button2, button3, routes: geojsonFeatures });
    } catch (err) {
      console.error('Error al obtener datos de PostgreSQL:', err);
      res.status(500).send('Error al obtener datos de PostgreSQL');
    }
  });
  
  
  app.get('/FEDME/Area', (req, res) => {
      const pageTitle = "Buscando el norte";
      const pageSubtitle = "Andando se hace el camino";
      const searchString = ""; 
      const button1 = {
        title: "Busqueda por nombre",
        description: "Se hara una busqueda por nombre",
        link: "/FEDME/Nombres"
      };
      const button2 = {
        title: "Busqueda por dificultad",
        description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
        link: "/FEDME/Dificultad"
      };
      const button3 = {
        title: "Personalizado",
        description: "Se puede hacer una busqueda más concreta",
        link: "/FEDME/Personalizado"
      };
      res.render('web2-1', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
  });
  
  app.get('/FEDME/Dificultad', (req, res) => {
      const pageTitle = "Buscando el norte";
      const pageSubtitle = "Andando se hace el camino";
      const searchString = ""; 
      const button1 = {
        title: "Busqueda por nombre",
        description: "Se hara una busqueda por nombre",
        link: "/FEDME/Nombres"
      };
      const button2 = {
        title: "Area de busqueda",
        description: "Se hara una busqueda en el area visualizada en el mapa",
        link: "/FEDME/Area"
      };
      const button3 = {
        title: "Personalizado",
        description: "Se puede hacer una busqueda más concreta",
        link: "/FEDME/Personalizado"
      };
      res.render('web3-1', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
  });
  
  app.get('/FEDME/Personalizado', (req, res) => {
    const pageTitle = "Buscando el norte";
    const pageSubtitle = "Andando se hace el camino";
    const searchString = ""; 
    const button1 = {
      title: "Busqueda por nombre",
      description: "Se hara una busqueda por nombre",
      link: "/FEDME/Nombres"
    };
    const button2 = {
      title: "Area de busqueda",
      description: "Se hara una busqueda en el area visualizada en el mapa",
      link: "/FEDME/Area"
    };
    const button3 = {
      title: "Busqueda por dificultad",
      description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
      link: "/FEDME/Dificultad"
    };
    res.render('web4-1', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
  });
}
 
//////////////////////////////////////////////////////// Rutas para BICI
{
  app.get('/BICI/Nombres', async (req, res) => {
    try {
      
      const query = `
        SELECT
          ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, nombre
      
        FROM "BICI";
      `;
      const result = await pgClient.query(query);
      const geojsonFeatures = result.rows.map(row => ({
        type: "Feature",
        geometry: JSON.parse(row.geometry),
        properties: {
          etapas: row.nombre  
        }
      }));
      const pageTitle = "Buscando el norte";
      const pageSubtitle = "Andando se hace el camino";
      const searchString = ""; 
      const button1 = {
        title: "Area de busqueda",
        description: "Se hara una busqueda en el area visualizada en el mapa",
        link: "/BICI/Area"
      };
      const button2 = {
        title: "Busqueda por dificultad",
        description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
        link: "/BICI/Dificultad"
      };
      const button3 = {
        title: "Personalizado",
        description: "Se puede hacer una busqueda más concreta",
        link: "/BICI/Personalizado"
      };
  
      res.render('web1-2', { pageTitle, pageSubtitle, searchString, button1, button2, button3, routes: geojsonFeatures });
    } catch (err) {
      console.error('Error al obtener datos de PostgreSQL:', err);
      res.status(500).send('Error al obtener datos de PostgreSQL');
    }
  });
  
  
  app.get('/BICI/Area', (req, res) => {
      const pageTitle = "Buscando el norte";
      const pageSubtitle = "Andando se hace el camino";
      const searchString = ""; 
      const button1 = {
        title: "Busqueda por nombre",
        description: "Se hara una busqueda por nombre",
        link: "/BICI/Nombres"
      };
      const button2 = {
        title: "Busqueda por dificultad",
        description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
        link: "/BICI/Dificultad"
      };
      const button3 = {
        title: "Personalizado",
        description: "Se puede hacer una busqueda más concreta",
        link: "/BICI/Personalizado"
      };
      res.render('web2-2', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
  });
  
  app.get('/BICI/Dificultad', (req, res) => {
      const pageTitle = "Buscando el norte";
      const pageSubtitle = "Andando se hace el camino";
      const searchString = ""; 
      const button1 = {
        title: "Busqueda por nombre",
        description: "Se hara una busqueda por nombre",
        link: "/BICI/Nombres"
      };
      const button2 = {
        title: "Area de busqueda",
        description: "Se hara una busqueda en el area visualizada en el mapa",
        link: "/BICI/Area"
      };
      const button3 = {
        title: "Personalizado",
        description: "Se puede hacer una busqueda más concreta",
        link: "/BICI/Personalizado"
      };
      res.render('web3-2', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
  });
  
  app.get('/BICI/Personalizado', (req, res) => {
    const pageTitle = "Buscando el norte";
    const pageSubtitle = "Andando se hace el camino";
    const searchString = ""; 
    const button1 = {
      title: "Busqueda por nombre",
      description: "Se hara una busqueda por nombre",
      link: "/BICI/Nombres"
    };
    const button2 = {
      title: "Area de busqueda",
      description: "Se hara una busqueda en el area visualizada en el mapa",
      link: "/BICI/Area"
    };
    const button3 = {
      title: "Busqueda por dificultad",
      description: "Se hara una busqueda de los tramos segun la dificultad seleccionada",
      link: "/BICI/Dificultad"
    };
    res.render('web4-2', { pageTitle, pageSubtitle, searchString, button1, button2, button3 });
  });
}
 


//////////////////////////////////////////////////////////////////// Parte de usuario
{

app.get('/registro', (req, res) => {
  res.render('registro');
});


// Ruta para obtener los favoritos del usuario
app.get('/getUserFavorites', verificarToken, async (req, res) => {
  const username = req.usuario.username;

  try {
      // Buscar al usuario por nombre de usuario y obtener solo los favoritos
      const usuario = await Usuario.findOne({ username }, 'favoritos');

      if (!usuario) {
          return res.status(404).json({ error: 'Usuario no encontrado' });
      }

      res.json({ favoritos: usuario.favoritos });
  } catch (error) {
      console.error('Error al obtener favoritos:', error);
      res.status(500).json({ error: 'Error al obtener favoritos' });
    }
});


// Ruta para añadir a favoritos
app.post('/addToFavorites', verificarToken, async (req, res) => {
  const { etapaNombre } = req.body;
  const username = req.usuario.username;

  try {
      // Buscar al usuario por nombre de usuario
      const usuario = await Usuario.findOne({ username });

      if (!usuario) {
          return res.status(404).json({ error: 'Usuario no encontrado' });
      }

      // Verificar si la etapa ya está en favoritos
      const existeEtapa = usuario.favoritos.some(fav => fav.nombre === etapaNombre);
      if (existeEtapa) {
          return res.status(400).json({ message: 'La etapa ya está en favoritos' });
      }

      // Agregar la etapa a favoritos
      usuario.favoritos.push({ nombre: etapaNombre });
      await usuario.save();

      res.json({ message: 'Etapa agregada a favoritos correctamente' });
  } catch (error) {
      console.error('Error al agregar a favoritos:', error);
      res.status(500).json({ error: 'Error al agregar a favoritos' });
  }
});


//Ruta para eliminar de favoritos
app.post('/removeFromFavorites', verificarToken, async (req, res) => {
  const { favoritoId } = req.body;
  const username = req.usuario.username;

  try {
      const usuario = await Usuario.findOne({ username });

      if (!usuario) {
          return res.status(404).json({ error: 'Usuario no encontrado' });
      }

      usuario.favoritos = usuario.favoritos.filter(fav => fav._id.toString() !== favoritoId);

      await usuario.save();

      res.json({ success: true, message: 'Favorito eliminado correctamente' });
  } catch (error) {
      console.error('Error al eliminar favorito:', error);
      res.status(500).json({ error: 'Error al eliminar favorito' });
  }
});




app.post('/registrar', async (req, res) => {
  const { username, correo, password, confirm_password } = req.body;
  //Verifica que las contraseñas coinciden
  if (password !== confirm_password) {
    return res.status(400).send('Las contraseñas no coinciden');
  }
  // Verifica que el correo tiene un formato válido
  const correoRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!correoRegex.test(correo)) {
    return res.status(400).send('El correo no tiene un formato válido');
  }
  //Verifica que el correo no se ha registrado antes
  try {
    const existingUser = await Usuario.findOne({ correo: correo });
    if (existingUser) {
      return res.status(400).send('Este correo ya ha sido registrado');
    }
    // Crear el hash de la contraseña
    const passwordHash = await bcrypt.hash(password, 10); // Genera un hash con sal de 10 rondas
    const nuevoUsuario = new Usuario({
      username: username,
      correo: correo,
      passwordHash: passwordHash // Guardamos el hash en lugar de la contraseña en texto plano
    });
    await nuevoUsuario.save();
    res.redirect('/?registro=exitoso');
  } catch (error) {
    res.status(500).send('Error al registrar usuario: ' + error);
  }
});

app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // Registro de datos de entrada para depuración
  console.log('Datos de inicio de sesión recibidos:', { username, password });

  try {
    const usuarioEncontrado = await Usuario.findOne({ username });
    if (!usuarioEncontrado) {
      return res.redirect('/?login=usuario_no_encontrado');
    }
    console.log('Usuario encontrado:', usuarioEncontrado);

    if (!usuarioEncontrado.passwordHash) {
      return res.status(500).send('Error interno: Usuario sin contraseña hash');
    }

    const passwordMatch = await bcrypt.compare(password, usuarioEncontrado.passwordHash);
    if (!passwordMatch) {
      console.log('Contraseña incorrecta');
      return res.redirect('/?login=contraseña_incorrecta');
    }
    // Generar token JWT
    const token = jwt.sign({ username: usuarioEncontrado.username }, process.env.JWT_SECRET, {
      expiresIn: '1h' // Tiempo de expiración del token (ej: 1 hora)
    });
    // Guardar el token en una cookie o enviarlo en la respuesta
    res.cookie('token', token, { httpOnly: true }); // Guarda el token en una cookie (opcional)
    res.redirect('/index2'); // Redirige a index2
  } catch (error) {
    console.error('Error al iniciar sesión:', error);
    res.status(500).send('Error al iniciar sesión');
  }
});


// Middleware para verificar token JWT
function verificarToken(req, res, next) {
  const token = req.cookies.token || ''; // Puedes enviar el token en cookies o en el header Authorization
  if (!token) {
    return res.redirect('/?login=acceso_denegado');
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.usuario = decoded; // Guarda la información decodificada del usuario en req.usuario
    next(); // Continúa con la siguiente función middleware o ruta
  } catch (error) {
    console.error('Error al verificar token:', error);
    return res.redirect('/?login=acceso_denegado');
  }
}

// Ejemplo de ruta protegida
app.get('/index2', verificarToken, (req, res) => {
  res.render('index2');
});

//Cerrar Sesion
app.get('/logout', (req, res) => {
  res.clearCookie('token'); // Borra la cookie que contiene el token
  res.redirect('/?login=sesion_cerrada'); // Redirige al usuario a la página de inicio
});
}

/////////////////////////////////////////////////////////////////////////////////////////////////CONSULTAS POSTGRESSQL

///////////////////////////////////////////////////////////SANTIAGO
{
//////////////////Busqueda por Nombres

// Unificar rutas de búsqueda de rutas
app.post('/search', async (req, res) => {
  const searchString = req.body.searchString || '';
  const longitude = req.body.longitude || null;
  const latitude = req.body.latitude || null;

  let query;
  let params = [];

  if (searchString) {
    query = `
      SELECT ST_AsGeoJSON(ST_Force2D(s.geom)) AS geometry, s.etapa
      FROM "Santiago" s
      JOIN "Municipios" m ON ST_Intersects(s.geom, m.geom)
      JOIN "Provincias" p ON ST_Intersects(s.geom, p.geom)
      WHERE m.nameunit ILIKE $1 OR p.nameunit ILIKE $1
    `;
    params.push(`%${searchString}%`);
  } else if (longitude !== null && latitude !== null) {
    query = `
      SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, etapa
      FROM "Santiago" s
      WHERE ST_Contains(s.geom, ST_SetSRID(ST_Point($1, $2), 4326))
    `;
    params.push(longitude, latitude);
  } else {
    return res.status(400).json({ error: 'Faltan parámetros de búsqueda' });
  }

  try {
    const result = await pgClient.query(query, params);
    const geojsonFeatures = result.rows.map(row => ({
      type: "Feature",
      geometry: JSON.parse(row.geometry),
      properties: {
        etapa: row.etapa // Incluir etapa en properties
      }
    }));
    res.json({ type: "FeatureCollection", features: geojsonFeatures });
  } catch (err) {
    console.error('Error al buscar rutas:', err);
    res.status(500).json({ error: 'Error al buscar rutas' });
  }
});

/////////////////////// Nueva ruta para obtener datos de PostgreSQL basado en las coordenadas maximas y minimas
app.post('/getGeoJSON', async (req, res) => {
    const { minLat, minLng, maxLat, maxLng } = req.body;
    try {
        const query = `
            SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geojson, etapa
            FROM "Santiago"
            WHERE ST_Within(geom, ST_MakeEnvelope($1, $2, $3, $4, 4326));
        `;
        const { rows } = await pgClient.query(query, [minLng, minLat, maxLng, maxLat]);
        const geojsonFeatures = rows.map(row => ({
            type: "Feature",
            geometry: JSON.parse(row.geojson),
            properties: {
                etapa: row.etapa
            }
        }));
        res.json({ type: "FeatureCollection", features: geojsonFeatures }); // Enviar datos GeoJSON como respuesta
    } catch (error) {
        console.error('Error al consultar datos:', error);
        res.status(500).json({ error: 'Error al consultar datos' });
    }
});

////////////////////////////////////////////////Dificultad

app.post('/getGeoJSONByDifficulty', async (req, res) => {
  const { difficulty } = req.body;
  try {
    let minDesnivel, maxDesnivel;

    // Definir los rangos de desnivel según el nivel de dificultad
    switch (difficulty) {
      case 1: // Fácil
        minDesnivel = 0;
        maxDesnivel = 300;
        break;
      case 2: // Medio
        minDesnivel = 301;
        maxDesnivel = 500;
        break;
      case 3: // Difícil
        minDesnivel = 501;
        maxDesnivel = 900;
        break;
      case 4: // Experto
        minDesnivel = 901;
        maxDesnivel = Infinity; // No hay límite superior para expertos
        break;
      default:
        return res.status(400).json({ error: 'Nivel de dificultad no válido' });
    }

    // Consulta para obtener datos GeoJSON desde la base de datos según el desnivel
    const query = `
      SELECT ST_AsGeoJSON(geom) AS geojson, etapa
      FROM "Santiago"
      WHERE (ST_ZMax(geom) - ST_ZMin(geom)) BETWEEN $1 AND $2;
    `;
    console.log('Ejecutando consulta:', query, [minDesnivel, maxDesnivel]); // Depuración
    const { rows } = await pgClient.query(query, [minDesnivel, maxDesnivel]);
    console.log('Filas obtenidas:', rows); // Depuración

    const features = rows.map(row => ({
      type: 'Feature',
      geometry: JSON.parse(row.geojson),
      properties: {
        etapa: row.etapa // Incluir la etapa en las propiedades
      }
    }));
    const geoJsonData = { type: 'FeatureCollection', features };
    console.log('GeoJSON Data:', geoJsonData); // Depuración

    res.json(geoJsonData); // Enviar datos GeoJSON como respuesta
  } catch (error) {
    console.error('Error al consultar datos:', error);
    res.status(500).json({ error: 'Error al consultar datos' });
  }
});



// Ruta para filtrar rutas por distancia y dificultad
app.post('/getFilteredRoutes', async (req, res) => {
    const { distance, difficulty } = req.body;

    try {
        let maxDistance = parseInt(distance) || Infinity;

        // Validar el nivel de dificultad
        switch (difficulty) {
            case '1': // Fácil
                break;
            case '2': // Intermedio
                break;
            case '3': // Difícil
                break;
            case '4': // Experto
                break;
            default:
                return res.status(400).json({ error: 'Nivel de dificultad no válido' });
        }

        // Consulta SQL para obtener rutas filtradas por distancia máxima
        const query = `
            SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, etapa, lon_etapa
            FROM "Santiago"
            WHERE lon_etapa <= $1;
        `;

        const result = await pgClient.query(query, [maxDistance]);

        // Mapear resultados a formato GeoJSON
        const geojsonFeatures = result.rows.map(row => ({
            type: "Feature",
            geometry: JSON.parse(row.geometry),
            properties: {
                etapa: row.etapa, // Incluir la etapa en las propiedades
                lon_etapa: row.lon_etapa
            }
        }));

        res.json({ type: "FeatureCollection", features: geojsonFeatures });
    } catch (err) {
        console.error('Error al obtener rutas filtradas:', err);
        res.status(500).json({ error: 'Error al obtener rutas filtradas' });
    }
});
}
/////////////////////////////////////////////////////////


///////////////////////////////////////////////////////////FEDME
{
//////////////////Busqueda por Nombres

// Unificar rutas de búsqueda de rutas
app.post('/search-1', async (req, res) => {
  const searchString = req.body.searchString || '';
  const longitude = req.body.longitude || null;
  const latitude = req.body.latitude || null;

  let query;
  let params = [];

  if (searchString) {
    query = `
      SELECT ST_AsGeoJSON(ST_Force2D(f.geom)) AS geometry, f.nombre
      FROM "FEDME" f
      JOIN "Municipios" m ON ST_Intersects(f.geom, m.geom)
      JOIN "Provincias" p ON ST_Intersects(f.geom, p.geom)
      WHERE m.nameunit ILIKE $1 OR p.nameunit ILIKE $1
    `;
    params.push(`%${searchString}%`);
  } else if (longitude !== null && latitude !== null) {
    query = `
      SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, nombre
      FROM "FEDME" f
      WHERE ST_Contains(f.geom, ST_SetSRID(ST_Point($1, $2), 4326))
    `;
    params.push(longitude, latitude);
  } else {
    return res.status(400).json({ error: 'Faltan parámetros de búsqueda' });
  }

  try {
    const result = await pgClient.query(query, params);
    const geojsonFeatures = result.rows.map(row => ({
      type: "Feature",
      geometry: JSON.parse(row.geometry),
      properties: {
        etapa: row.nombre // Incluir etapa en properties
      }
    }));
    res.json({ type: "FeatureCollection", features: geojsonFeatures });
  } catch (err) {
    console.error('Error al buscar rutas:', err);
    res.status(500).json({ error: 'Error al buscar rutas' });
  }
});

/////////////////////// Nueva ruta para obtener datos de PostgreSQL basado en las coordenadas maximas y minimas
app.post('/getGeoJSON-1', async (req, res) => {
    const { minLat, minLng, maxLat, maxLng } = req.body;
    try {
        const query = `
            SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geojson, nombre
            FROM "FEDME"
            WHERE ST_Within(geom, ST_MakeEnvelope($1, $2, $3, $4, 4326));
        `;
        const { rows } = await pgClient.query(query, [minLng, minLat, maxLng, maxLat]);
        const geojsonFeatures = rows.map(row => ({
            type: "Feature",
            geometry: JSON.parse(row.geojson),
            properties: {
                etapa: row.nombre
            }
        }));
        res.json({ type: "FeatureCollection", features: geojsonFeatures }); // Enviar datos GeoJSON como respuesta
    } catch (error) {
        console.error('Error al consultar datos:', error);
        res.status(500).json({ error: 'Error al consultar datos' });
    }
});

////////////////////////////////////////////////Dificultad

app.post('/getGeoJSONByDifficulty-1', async (req, res) => {
  const { difficulty } = req.body;
  try {
    let minDesnivel, maxDesnivel;

    // Definir los rangos de desnivel según el nivel de dificultad
    switch (difficulty) {
      case 1: // Fácil
        minDesnivel = 0;
        maxDesnivel = 300;
        break;
      case 2: // Medio
        minDesnivel = 301;
        maxDesnivel = 500;
        break;
      case 3: // Difícil
        minDesnivel = 501;
        maxDesnivel = 900;
        break;
      case 4: // Experto
        minDesnivel = 901;
        maxDesnivel = Infinity; // No hay límite superior para expertos
        break;
      default:
        return res.status(400).json({ error: 'Nivel de dificultad no válido' });
    }

    // Consulta para obtener datos GeoJSON desde la base de datos según el desnivel
    const query = `
      SELECT ST_AsGeoJSON(geom) AS geojson, nombre
      FROM "FEDME"
      WHERE (ST_ZMax(geom) - ST_ZMin(geom)) BETWEEN $1 AND $2;
    `;
    console.log('Ejecutando consulta:', query, [minDesnivel, maxDesnivel]); // Depuración
    const { rows } = await pgClient.query(query, [minDesnivel, maxDesnivel]);
    console.log('Filas obtenidas:', rows); // Depuración

    const features = rows.map(row => ({
      type: 'Feature',
      geometry: JSON.parse(row.geojson),
      properties: {
        etapa: row.nombre // Incluir la etapa en las propiedades
      }
    }));
    const geoJsonData = { type: 'FeatureCollection', features };
    console.log('GeoJSON Data:', geoJsonData); // Depuración

    res.json(geoJsonData); // Enviar datos GeoJSON como respuesta
  } catch (error) {
    console.error('Error al consultar datos:', error);
    res.status(500).json({ error: 'Error al consultar datos' });
  }
});



// Ruta para filtrar rutas por distancia y dificultad
app.post('/getFilteredRoutes-1', async (req, res) => {
    const { distance, difficulty } = req.body;

    try {
        let maxDistance = parseInt(distance) || Infinity;

        // Validar el nivel de dificultad
        switch (difficulty) {
            case '1': // Fácil
                break;
            case '2': // Intermedio
                break;
            case '3': // Difícil
                break;
            case '4': // Experto
                break;
            default:
                return res.status(400).json({ error: 'Nivel de dificultad no válido' });
        }

        // Consulta SQL para obtener rutas filtradas por distancia máxima
        const query = `
            SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, nombre, longitud
            FROM "FEDME"
            WHERE longitud <= $1;
        `;

        const result = await pgClient.query(query, [maxDistance]);

        // Mapear resultados a formato GeoJSON
        const geojsonFeatures = result.rows.map(row => ({
            type: "Feature",
            geometry: JSON.parse(row.geometry),
            properties: {
                etapa: row.nombre, // Incluir la etapa en las propiedades
                lon_etapa: row.longitud
            }
        }));

        res.json({ type: "FeatureCollection", features: geojsonFeatures });
    } catch (err) {
        console.error('Error al obtener rutas filtradas:', err);
        res.status(500).json({ error: 'Error al obtener rutas filtradas' });
    }
});
}
/////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////BICI
{
//////////////////Busqueda por Nombres

// Unificar rutas de búsqueda de rutas
app.post('/search-2', async (req, res) => {
  const searchString = req.body.searchString || '';
  const longitude = req.body.longitude || null;
  const latitude = req.body.latitude || null;

  let query;
  let params = [];

  if (searchString) {
    query = `
      SELECT ST_AsGeoJSON(ST_Force2D(b.geom)) AS geometry, b.nombre
      FROM "BICI" b
      JOIN "Municipios" m ON ST_Intersects(b.geom, m.geom)
      JOIN "Provincias" p ON ST_Intersects(b.geom, p.geom)
      WHERE m.nameunit ILIKE $1 OR p.nameunit ILIKE $1
    `;
    params.push(`%${searchString}%`);
  } else if (longitude !== null && latitude !== null) {
    query = `
      SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, nombre
      FROM "BICI" b
      WHERE ST_Contains(b.geom, ST_SetSRID(ST_Point($1, $2), 4326))
    `;
    params.push(longitude, latitude);
  } else {
    return res.status(400).json({ error: 'Faltan parámetros de búsqueda' });
  }

  try {
    const result = await pgClient.query(query, params);
    const geojsonFeatures = result.rows.map(row => ({
      type: "Feature",
      geometry: JSON.parse(row.geometry),
      properties: {
        etapa: row.nombre // Incluir etapa en properties
      }
    }));
    res.json({ type: "FeatureCollection", features: geojsonFeatures });
  } catch (err) {
    console.error('Error al buscar rutas:', err);
    res.status(500).json({ error: 'Error al buscar rutas' });
  }
});

/////////////////////// Nueva ruta para obtener datos de PostgreSQL basado en las coordenadas maximas y minimas
app.post('/getGeoJSON-2', async (req, res) => {
    const { minLat, minLng, maxLat, maxLng } = req.body;
    try {
        const query = `
            SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geojson, nombre
            FROM "BICI"
            WHERE ST_Within(geom, ST_MakeEnvelope($1, $2, $3, $4, 4326));
        `;
        const { rows } = await pgClient.query(query, [minLng, minLat, maxLng, maxLat]);
        const geojsonFeatures = rows.map(row => ({
            type: "Feature",
            geometry: JSON.parse(row.geojson),
            properties: {
                etapa: row.nombre
            }
        }));
        res.json({ type: "FeatureCollection", features: geojsonFeatures }); // Enviar datos GeoJSON como respuesta
    } catch (error) {
        console.error('Error al consultar datos:', error);
        res.status(500).json({ error: 'Error al consultar datos' });
    }
});

////////////////////////////////////////////////Dificultad

app.post('/getGeoJSONByDifficulty-2', async (req, res) => {
  const { difficulty } = req.body;
  try {
    let minDesnivel, maxDesnivel;

    // Definir los rangos de desnivel según el nivel de dificultad
    switch (difficulty) {
      case 1: // Fácil
        minDesnivel = 0;
        maxDesnivel = 300;
        break;
      case 2: // Medio
        minDesnivel = 301;
        maxDesnivel = 500;
        break;
      case 3: // Difícil
        minDesnivel = 501;
        maxDesnivel = 900;
        break;
      case 4: // Experto
        minDesnivel = 901;
        maxDesnivel = Infinity; // No hay límite superior para expertos
        break;
      default:
        return res.status(400).json({ error: 'Nivel de dificultad no válido' });
    }

    // Consulta para obtener datos GeoJSON desde la base de datos según el desnivel
    const query = `
      SELECT ST_AsGeoJSON(geom) AS geojson, nombre
      FROM "BICI"
      WHERE (ST_ZMax(geom) - ST_ZMin(geom)) BETWEEN $1 AND $2;
    `;
    console.log('Ejecutando consulta:', query, [minDesnivel, maxDesnivel]); // Depuración
    const { rows } = await pgClient.query(query, [minDesnivel, maxDesnivel]);
    console.log('Filas obtenidas:', rows); // Depuración

    const features = rows.map(row => ({
      type: 'Feature',
      geometry: JSON.parse(row.geojson),
      properties: {
        etapa: row.nombre // Incluir la etapa en las propiedades
      }
    }));
    const geoJsonData = { type: 'FeatureCollection', features };
    console.log('GeoJSON Data:', geoJsonData); // Depuración

    res.json(geoJsonData); // Enviar datos GeoJSON como respuesta
  } catch (error) {
    console.error('Error al consultar datos:', error);
    res.status(500).json({ error: 'Error al consultar datos' });
  }
});



// Ruta para filtrar rutas por distancia y dificultad
app.post('/getFilteredRoutes-2', async (req, res) => {
    const { distance, difficulty } = req.body;

    try {
        let maxDistance = parseInt(distance) || Infinity;

        // Validar el nivel de dificultad
        switch (difficulty) {
            case '1': // Fácil
                break;
            case '2': // Intermedio
                break;
            case '3': // Difícil
                break;
            case '4': // Experto
                break;
            default:
                return res.status(400).json({ error: 'Nivel de dificultad no válido' });
        }

        // Consulta SQL para obtener rutas filtradas por distancia máxima
        const query = `
            SELECT ST_AsGeoJSON(ST_Force2D(geom)) AS geometry, nombre, longitud
            FROM "BICI"
            WHERE longitud <= $1;
        `;

        const result = await pgClient.query(query, [maxDistance]);

        // Mapear resultados a formato GeoJSON
        const geojsonFeatures = result.rows.map(row => ({
            type: "Feature",
            geometry: JSON.parse(row.geometry),
            properties: {
                etapa: row.nombre, // Incluir la etapa en las propiedades
                lon_etapa: row.longitud
            }
        }));

        res.json({ type: "FeatureCollection", features: geojsonFeatures });
    } catch (err) {
        console.error('Error al obtener rutas filtradas:', err);
        res.status(500).json({ error: 'Error al obtener rutas filtradas' });
    }
});
}
/////////////////////////////////////////////////////////




//////////////////////////////(no duplicar)
app.post('/autocomplete', async (req, res) => {
  const term = req.body.term;

  const query = `
    SELECT DISTINCT nameunit
    FROM (
      SELECT nameunit FROM "Municipios" WHERE nameunit ILIKE $1
      UNION
      SELECT nameunit FROM "Provincias" WHERE nameunit ILIKE $1
    ) AS resultados
    LIMIT 10;
  `;
  
  try {
    const result = await pgClient.query(query, [`%${term}%`]);
    const suggestions = result.rows.map(row => row.nameunit);
    res.json(suggestions);
  } catch (err) {
    console.error('Error en autocompletado:', err);
    res.status(500).json({ error: 'Error en autocompletado' });
  }
});
////////////////////////////





////////////////////////////////////////////////////////////////////////////////////////////////// Iniciar servidor Node
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`Servidor en funcionamiento en el puerto ${PORT}`);
});