Instalacion de librerias necesarias: 
-pg
-mongoose
-bcrypt
-bcryptjs
-body-parser
-connect-flash
-cookie-parser
-debug
-dotenv
-ejs
-express
-express-session
-express-validator
-http-errors
-jsonwebtoken
-morgan
-passport
-passport-local

Lanzador del programa Node: (apuntar al directorio dentro de BUSCANDOELNORTE) node app.js

La direccion web en la que se encuentra la pagina web: http://localhost:3001

El fichero .env: fichero para hasear las contraseñas